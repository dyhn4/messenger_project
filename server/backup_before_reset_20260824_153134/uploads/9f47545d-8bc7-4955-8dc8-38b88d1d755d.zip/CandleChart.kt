package com.example.trendscan.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.example.trendscan.data.Candle
import com.example.trendscan.domain.sma
import kotlin.math.roundToInt

/** 첨부 이미지에서 추출한 색. 기간2(20일) / 기간3(60일). */
val MA20_COLOR = Color(0xFFE6485C)
val MA60_COLOR = Color(0xFFEE8210)

private val BG = Color(0xFF1C1D22)
private val GRID = Color(0xFF2E3038)
private val UP_CANDLE = Color(0xFFD24B4B)     // 양봉(빨강) — MA20보다 살짝 어둡게 해서 선이 위로 읽히게
private val DOWN_CANDLE = Color(0xFF3E7FD1)   // 음봉(파랑)
private val VOLUME = Color(0xFF4A4D57)
private val TEXT_DIM = Color(0xFF8B8F9A)

/**
 * 일봉 + 이동평균선 차트.
 *
 * 축 라벨과 여백을 직접 제어해야 해서 기성 차트 라이브러리 대신 Canvas로 그립니다.
 * 핀치로 확대/축소, 드래그로 좌우 이동합니다.
 */
@Composable
fun CandleChart(
    candles: List<Candle>,
    modifier: Modifier = Modifier,
    maPeriods: Pair<Int, Int> = 20 to 60,
    initialVisible: Int = 120,
) {
    if (candles.isEmpty()) {
        Box(modifier.background(BG), Alignment.Center) {
            Text("데이터 없음", color = TEXT_DIM, fontSize = 13.sp)
        }
        return
    }

    val closes = remember(candles) { candles.map { it.close } }
    val maShort = remember(closes, maPeriods) { sma(closes, maPeriods.first) }
    val maLong = remember(closes, maPeriods) { sma(closes, maPeriods.second) }

    var visible by remember(candles) { mutableStateOf(minOf(initialVisible, candles.size)) }
    var endIndex by remember(candles) { mutableStateOf(candles.lastIndex) }

    Column(modifier.background(BG)) {
        MaLegend(maPeriods, candles.size, visible)

        Canvas(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .pointerInput(candles) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (zoom != 1f) {
                            visible = (visible / zoom).roundToInt()
                                .coerceIn(20, candles.size)
                        }
                        if (pan.x != 0f) {
                            val perPx = visible / size.width.toFloat()
                            endIndex = (endIndex - pan.x * perPx).roundToInt()
                                .coerceIn(visible - 1, candles.lastIndex)
                        }
                        endIndex = endIndex.coerceIn(
                            minOf(visible - 1, candles.lastIndex), candles.lastIndex
                        )
                    }
                }
        ) {
            val start = (endIndex - visible + 1).coerceAtLeast(0)
            val slice = start..endIndex
            if (slice.isEmpty()) return@Canvas

            val priceH = size.height * 0.76f
            val volTop = size.height * 0.80f
            val volH = size.height - volTop

            // 가격 범위는 캔들뿐 아니라 이동평균선까지 포함해야 선이 잘리지 않습니다.
            var lo = Double.MAX_VALUE
            var hi = -Double.MAX_VALUE
            for (i in slice) {
                lo = minOf(lo, candles[i].low)
                hi = maxOf(hi, candles[i].high)
                maShort[i]?.let { lo = minOf(lo, it); hi = maxOf(hi, it) }
                maLong[i]?.let { lo = minOf(lo, it); hi = maxOf(hi, it) }
            }
            val pad = (hi - lo) * 0.06
            lo -= pad; hi += pad
            val span = (hi - lo).takeIf { it > 0 } ?: 1.0

            val maxVol = slice.maxOf { candles[it].volume }.takeIf { it > 0 } ?: 1.0
            val slotW = size.width / visible
            val bodyW = (slotW * 0.62f).coerceAtLeast(1f)

            fun yOf(p: Double) = (priceH * (1.0 - (p - lo) / span)).toFloat()
            fun xOf(i: Int) = (i - start) * slotW + slotW / 2f

            // 가로 그리드 4등분
            repeat(5) { k ->
                val y = priceH * k / 4f
                drawLine(GRID, Offset(0f, y), Offset(size.width, y), 1f)
            }

            // 캔들 + 거래량
            for (i in slice) {
                val c = candles[i]
                val x = xOf(i)
                val color = if (c.close >= c.open) UP_CANDLE else DOWN_CANDLE

                drawLine(color, Offset(x, yOf(c.high)), Offset(x, yOf(c.low)), 1f)

                val top = yOf(maxOf(c.open, c.close))
                val bot = yOf(minOf(c.open, c.close))
                drawRect(
                    color = color,
                    topLeft = Offset(x - bodyW / 2f, top),
                    size = Size(bodyW, (bot - top).coerceAtLeast(1f)),
                )

                val vh = (volH * (c.volume / maxVol)).toFloat()
                drawRect(
                    color = VOLUME,
                    topLeft = Offset(x - bodyW / 2f, volTop + volH - vh),
                    size = Size(bodyW, vh),
                )
            }

            // 이동평균선 — 60일선을 먼저 그려 20일선이 위로 올라오게 합니다.
            drawMaLine(maLong, slice, MA60_COLOR, ::xOf, ::yOf)
            drawMaLine(maShort, slice, MA20_COLOR, ::xOf, ::yOf)
        }
    }
}

private fun DrawScope.drawMaLine(
    ma: List<Double?>,
    range: IntRange,
    color: Color,
    xOf: (Int) -> Float,
    yOf: (Double) -> Float,
) {
    val path = Path()
    var started = false
    for (i in range) {
        val v = ma.getOrNull(i)
        if (v == null) { started = false; continue }   // 값 없는 구간은 선을 끊습니다
        val p = Offset(xOf(i), yOf(v))
        if (!started) { path.moveTo(p.x, p.y); started = true } else path.lineTo(p.x, p.y)
    }
    drawPath(path, color, style = Stroke(width = 1.6f))
}

/** 첨부 이미지의 설정 패널과 같은 순서(색 스와치 → 기간)로 범례를 답니다. */
@Composable
private fun MaLegend(periods: Pair<Int, Int>, total: Int, visible: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LegendChip(MA20_COLOR, "${periods.first}")
        Spacer(Modifier.width(14.dp))
        LegendChip(MA60_COLOR, "${periods.second}")
        Spacer(Modifier.weight(1f))
        Text("$visible / $total", color = TEXT_DIM, fontSize = 11.sp)
    }
}

@Composable
private fun LegendChip(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text("${label}일", color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
