package com.example.trendscan.domain

import com.example.trendscan.data.Candle
import kotlin.math.abs
import kotlin.math.ln

/**
 * 단순이동평균. 구간이 덜 찬 앞부분은 null이라 차트에서 선이 끊깁니다.
 * (HTS와 동일한 동작입니다 — 60일선은 61번째 봉부터 그려집니다.)
 */
fun sma(values: List<Double>, period: Int): List<Double?> {
    if (period <= 0) return List(values.size) { null }
    val out = arrayOfNulls<Double>(values.size)
    var sum = 0.0
    for (i in values.indices) {
        sum += values[i]
        if (i >= period) sum -= values[i - period]
        if (i >= period - 1) out[i] = sum / period
    }
    return out.toList()
}

enum class Direction { UP, DOWN, NEUTRAL }

data class TrendResult(
    val code: String,
    val name: String,
    val direction: Direction,
    /** 60일선이 최근 20거래일 동안 몇 % 움직였는가. 추세의 방향과 세기. */
    val ma60SlopePct: Double,
    /** 20일선이 최근 10거래일 동안 몇 % 움직였는가. */
    val ma20SlopePct: Double,
    /** log(종가) 선형회귀 결정계수. 1에 가까울수록 "깔끔한" 추세. */
    val r2: Double,
    /** 최근 60거래일 중 정배열(또는 역배열)이 유지된 비율. */
    val alignment: Double,
    /** 0~100. 정렬 기준. */
    val score: Double,
    val lastClose: Double,
) {
    val label: String get() = when (direction) {
        Direction.UP -> "우상향"
        Direction.DOWN -> "우하향"
        Direction.NEUTRAL -> "횡보"
    }
}

/**
 * 추세 판정.
 *
 * "우상향"을 눈으로 볼 때 사람이 실제로 보는 건 세 가지입니다:
 *   ① 60일선이 우상향하고 있는가 (방향)
 *   ② 20일선이 60일선 위에 꾸준히 있었는가 (정배열 지속성)
 *   ③ 가격이 그 주변을 크게 벗어나지 않고 따라왔는가 (추세의 깔끔함)
 *
 * 이 셋을 각각 수치화해서 합칩니다. ③을 R²로 잡는 게 핵심인데,
 * 이게 없으면 "한 번 급등하고 옆으로 긴" 종목이 우상향으로 잡힙니다.
 */
fun analyzeTrend(
    code: String,
    name: String,
    candles: List<Candle>,
    regressionWindow: Int = 120,
    alignmentWindow: Int = 60,
    slopeThresholdPct: Double = 3.0,
): TrendResult? {
    if (candles.size < 80) return null   // 60일선조차 안정적으로 안 나옵니다.

    val closes = candles.map { it.close }
    val ma20 = sma(closes, 20)
    val ma60 = sma(closes, 60)
    val last = closes.lastIndex

    val ma60Now = ma60[last] ?: return null
    val ma60Past = ma60.getOrNull(last - 20) ?: return null
    val ma20Now = ma20[last] ?: return null
    val ma20Past = ma20.getOrNull(last - 10) ?: return null

    val ma60Slope = (ma60Now - ma60Past) / ma60Past * 100.0
    val ma20Slope = (ma20Now - ma20Past) / ma20Past * 100.0

    // ③ 추세의 깔끔함 — 로그 종가에 직선을 맞춘 뒤 결정계수
    val win = closes.takeLast(minOf(regressionWindow, closes.size))
    val r2 = logLinearR2(win)

    // ② 정배열/역배열 지속성
    val alignStart = maxOf(0, last - alignmentWindow + 1)
    var above = 0
    var counted = 0
    for (i in alignStart..last) {
        val a = ma20[i] ?: continue
        val b = ma60[i] ?: continue
        counted++
        if (a > b) above++
    }
    val aboveRatio = if (counted == 0) 0.5 else above.toDouble() / counted

    val direction = when {
        ma60Slope >= slopeThresholdPct && ma20Now > ma60Now -> Direction.UP
        ma60Slope <= -slopeThresholdPct && ma20Now < ma60Now -> Direction.DOWN
        else -> Direction.NEUTRAL
    }

    val alignment = when (direction) {
        Direction.UP -> aboveRatio
        Direction.DOWN -> 1.0 - aboveRatio
        Direction.NEUTRAL -> maxOf(aboveRatio, 1.0 - aboveRatio)
    }

    // 기울기는 30%에서 포화시킵니다. 그 이상은 추세라기보다 급등락이라
    // 더 높은 점수를 줄 이유가 없습니다.
    val slopeScore = (abs(ma60Slope) / 30.0).coerceAtMost(1.0)
    val score = (slopeScore * 0.40 + r2 * 0.35 + alignment * 0.25) * 100.0

    return TrendResult(
        code = code,
        name = name,
        direction = direction,
        ma60SlopePct = ma60Slope,
        ma20SlopePct = ma20Slope,
        r2 = r2,
        alignment = alignment,
        score = if (direction == Direction.NEUTRAL) score * 0.3 else score,
        lastClose = closes.last(),
    )
}

/** log(y) = a + b·x 회귀의 결정계수. 지수 성장/감소를 직선으로 보기 위해 로그를 씌웁니다. */
private fun logLinearR2(values: List<Double>): Double {
    val ys = values.filter { it > 0 }.map { ln(it) }
    val n = ys.size
    if (n < 10) return 0.0

    val meanX = (n - 1) / 2.0
    val meanY = ys.average()
    var sxy = 0.0; var sxx = 0.0; var syy = 0.0
    for (i in 0 until n) {
        val dx = i - meanX
        val dy = ys[i] - meanY
        sxy += dx * dy; sxx += dx * dx; syy += dy * dy
    }
    if (sxx == 0.0 || syy == 0.0) return 0.0
    val r = sxy / kotlin.math.sqrt(sxx * syy)
    return r * r
}
