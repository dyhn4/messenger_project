package com.example.trendscan.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** 일봉 한 개. 가격은 원 단위, 이미 부호/콤마가 제거된 상태. */
data class Candle(
    val date: String,   // yyyyMMdd
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
)

class KiwoomException(val code: Int, override val message: String) : Exception(message)

/**
 * 키움 REST API 클라이언트 (조회 전용).
 *
 * 주의 — 이 클래스는 주문 API를 일부러 넣지 않았습니다. appkey/secret 자체는
 * 주문 권한을 가지므로, 화면 조작 실수로 주문이 나가는 경로를 아예 만들지 않는 게 안전합니다.
 */
class KiwoomApi(
    private val appKey: String,
    private val secretKey: String,
    private val mock: Boolean = false,
) {
    private val host = if (mock) "https://mockapi.kiwoom.com" else "https://api.kiwoom.com"

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val json = "application/json;charset=UTF-8".toMediaType()

    @Volatile private var token: String? = null
    @Volatile private var tokenIssuedAt = 0L
    private val tokenLock = Mutex()

    // 키움은 TR별로 호출 제한이 걸립니다. 실측상 초당 1회 수준이 안전선이라
    // 전역 게이트로 최소 간격을 강제합니다. 느리지만 429로 막히는 것보다 낫습니다.
    private val gate = Mutex()
    private var lastCallAt = 0L
    private val minIntervalMs = 1_100L

    private suspend fun throttle() = gate.withLock {
        val wait = minIntervalMs - (System.currentTimeMillis() - lastCallAt)
        if (wait > 0) delay(wait)
        lastCallAt = System.currentTimeMillis()
    }

    // ---------------------------------------------------------------- token

    private suspend fun accessToken(): String = tokenLock.withLock {
        val cached = token
        // 토큰 유효기간은 24시간이지만 여유를 두고 6시간마다 재발급합니다.
        if (cached != null && System.currentTimeMillis() - tokenIssuedAt < 6 * 3600_000L) {
            return@withLock cached
        }
        val body = JSONObject()
            .put("grant_type", "client_credentials")
            .put("appkey", appKey)
            .put("secretkey", secretKey)
            .toString()

        val req = Request.Builder()
            .url("$host/oauth2/token")
            .post(body.toRequestBody(json))
            .header("Content-Type", "application/json;charset=UTF-8")
            .build()

        val text = withContext(Dispatchers.IO) {
            http.newCall(req).execute().use { res ->
                res.body?.string().orEmpty().also {
                    if (!res.isSuccessful) throw KiwoomException(res.code, "토큰 발급 실패: $it")
                }
            }
        }
        val obj = JSONObject(text)
        // 문서 개정에 따라 필드명이 달라질 수 있어 후보를 모두 확인합니다.
        val t = obj.optString("token").ifBlank { obj.optString("access_token") }
        if (t.isBlank()) throw KiwoomException(-1, "토큰 응답에 token 필드가 없습니다: $text")
        token = t
        tokenIssuedAt = System.currentTimeMillis()
        t
    }

    // ------------------------------------------------------------- raw call

    private suspend fun post(
        path: String,
        apiId: String,
        payload: JSONObject,
        contYn: String? = null,
        nextKey: String? = null,
    ): Triple<JSONObject, String?, String?> {
        throttle()
        val bearer = accessToken()

        val builder = Request.Builder()
            .url("$host$path")
            .post(payload.toString().toRequestBody(json))
            .header("Content-Type", "application/json;charset=UTF-8")
            .header("authorization", "Bearer $bearer")
            .header("api-id", apiId)
        if (!contYn.isNullOrBlank()) builder.header("cont-yn", contYn)
        if (!nextKey.isNullOrBlank()) builder.header("next-key", nextKey)

        return withContext(Dispatchers.IO) {
            http.newCall(builder.build()).execute().use { res ->
                val text = res.body?.string().orEmpty()
                if (res.code == 429) throw KiwoomException(429, "호출 한도 초과. 간격을 늘리세요.")
                if (!res.isSuccessful) throw KiwoomException(res.code, "HTTP ${res.code}: $text")

                val obj = JSONObject(text)
                val rc = obj.optInt("return_code", 0)
                if (rc != 0) throw KiwoomException(rc, obj.optString("return_msg", "알 수 없는 오류"))

                Triple(obj, res.header("cont-yn"), res.header("next-key"))
            }
        }
    }

    // ------------------------------------------------------------ 일봉 차트

    /**
     * 주식일봉차트조회 (ka10081).
     *
     * @param code 6자리 종목코드. NXT/SOR은 "005930_NX" 형태로도 지정 가능.
     * @param minCount 최소 이 개수만큼 모일 때까지 연속조회를 반복합니다.
     *                 60일선을 그리려면 최소 60개, 추세 판정까지 하려면 200개 이상 권장.
     * @param adjusted 수정주가 적용 여부. 액면분할 갭 때문에 반드시 true 권장.
     */
    suspend fun dailyCandles(
        code: String,
        minCount: Int = 240,
        adjusted: Boolean = true,
        baseDate: String = "00000000",   // 00000000 = 현재일자
    ): List<Candle> {
        val out = mutableListOf<Candle>()
        var contYn: String? = null
        var nextKey: String? = null
        var guard = 0

        do {
            val payload = JSONObject()
                .put("stk_cd", code)
                .put("base_dt", baseDate)
                .put("upd_stkpc_tp", if (adjusted) "1" else "0")

            val (obj, cy, nk) = post("/api/dostk/chart", "ka10081", payload, contYn, nextKey)
            out += parseCandles(obj)

            contYn = cy
            nextKey = nk
            guard++
        } while (contYn == "Y" && out.size < minCount && guard < 12)

        // 키움은 최신순으로 내려주므로 과거→현재 순으로 뒤집어 정렬합니다.
        return out.distinctBy { it.date }.sortedBy { it.date }
    }

    /**
     * 응답 본문에서 캔들 배열을 찾아 파싱합니다.
     *
     * 배열 키 이름(stk_dt_pole_chart_qry 등)은 문서 개정으로 바뀔 수 있어
     * 하드코딩하지 않고 "본문에서 가장 큰 JSON 배열"을 캔들 목록으로 간주합니다.
     * 필드명도 후보를 순서대로 확인합니다.
     */
    private fun parseCandles(obj: JSONObject): List<Candle> {
        var best: JSONArray? = null
        for (key in obj.keys()) {
            val v = obj.opt(key)
            if (v is JSONArray && v.length() > (best?.length() ?: 0)) best = v
        }
        val arr = best ?: return emptyList()

        val result = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            val date = row.pick("dt", "base_dt", "stck_bsop_date") ?: continue
            val close = row.num("cur_prc", "close_pric", "clos_pric", "stck_clpr") ?: continue
            val open = row.num("open_pric", "opn_pric", "stck_oprc") ?: close
            val high = row.num("high_pric", "hgpr", "stck_hgpr") ?: close
            val low = row.num("low_pric", "lwpr", "stck_lwpr") ?: close
            val vol = row.num("trde_qty", "acml_vol", "cntg_qty") ?: 0.0
            result += Candle(date, open, high, low, close, vol)
        }
        return result
    }

    private fun JSONObject.pick(vararg keys: String): String? =
        keys.firstNotNullOfOrNull { k -> optString(k).takeIf { it.isNotBlank() } }

    /** 키움 가격 필드는 "+70700", "-1,250" 처럼 부호와 콤마가 붙어 옵니다. */
    private fun JSONObject.num(vararg keys: String): Double? {
        val raw = pick(*keys) ?: return null
        val cleaned = raw.replace(",", "").replace("+", "").trim()
        val v = cleaned.toDoubleOrNull() ?: return null
        return kotlin.math.abs(v)   // 음수 부호는 "전일 대비 하락" 표시이지 음의 가격이 아닙니다.
    }
}
