package com.example.trendscan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.trendscan.data.KiwoomApi
import com.example.trendscan.ui.MainScreen
import com.example.trendscan.ui.ScreenerViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // appkey/secret은 절대 소스에 하드코딩하지 않습니다.
        // 최초 1회만 아래 주석을 풀어 저장하고, 저장 후 다시 주석 처리한 뒤 재빌드하세요.
        val prefs = EncryptedSharedPreferences.create(
            applicationContext,
            "kiwoom",
            MasterKey.Builder(applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
        // prefs.edit().putString("appkey", "...").putString("secret", "...").apply()

        val appKey = prefs.getString("appkey", "") ?: ""
        val secret = prefs.getString("secret", "") ?: ""

        val api = KiwoomApi(appKey = appKey, secretKey = secret, mock = false)

        setContent {
            val vm: ScreenerViewModel = viewModel(factory = factoryOf(api))
            MainScreen(vm)
        }
    }

    private fun factoryOf(api: KiwoomApi) = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            ScreenerViewModel(api) as T
    }
}
