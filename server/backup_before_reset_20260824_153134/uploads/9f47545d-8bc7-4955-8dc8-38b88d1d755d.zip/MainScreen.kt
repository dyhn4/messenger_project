package com.example.trendscan.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.trendscan.domain.Direction
import com.example.trendscan.domain.TrendResult

private val BG = Color(0xFF17181C)
private val CARD = Color(0xFF1F2026)
private val TEXT = Color(0xFFE4E6EB)
private val TEXT_DIM = Color(0xFF8B8F9A)

@Composable
fun MainScreen(vm: ScreenerViewModel) {
    val s by vm.state.collectAsState()

    LaunchedEffect(Unit) { vm.scan() }

    Column(Modifier.fillMaxSize().background(BG)) {

        // 차트
        Box(Modifier.fillMaxWidth().height(320.dp)) {
            CandleChart(candles = s.candles, modifier = Modifier.fillMaxSize())
        }

        s.selected?.let { code ->
            s.results.firstOrNull { it.code == code }?.let { r ->
                Text(
                    "${r.name}  ${r.label}   60일선 ${fmt(r.ma60SlopePct)}%  ·  R² ${"%.2f".format(r.r2)}",
                    color = TEXT,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }

        FilterRow(s.filter, vm::setFilter)

        if (s.scanning) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = MA20_COLOR)
                Spacer(Modifier.width(10.dp))
                Text("스캔 중 ${s.progress}", color = TEXT_DIM, fontSize = 12.sp)
            }
        }

        s.error?.let {
            Text(it, color = MA20_COLOR, fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp))
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(s.visibleResults, key = { it.code }) { r ->
                ResultRow(r, selected = r.code == s.selected) { vm.select(r.code) }
            }
        }
    }
}

@Composable
private fun FilterRow(current: Direction?, onPick: (Direction?) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Chip("전체", current == null) { onPick(null) }
        Chip("우상향", current == Direction.UP, MA20_COLOR) { onPick(Direction.UP) }
        Chip("우하향", current == Direction.DOWN, MA60_COLOR) { onPick(Direction.DOWN) }
    }
}

@Composable
private fun Chip(label: String, active: Boolean, accent: Color = TEXT, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) accent.copy(alpha = 0.18f) else CARD)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(label, color = if (active) accent else TEXT_DIM, fontSize = 12.sp)
    }
}

@Composable
private fun ResultRow(r: TrendResult, selected: Boolean, onClick: () -> Unit) {
    val accent = when (r.direction) {
        Direction.UP -> MA20_COLOR
        Direction.DOWN -> MA60_COLOR
        Direction.NEUTRAL -> TEXT_DIM
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) accent.copy(alpha = 0.12f) else CARD)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(r.name, color = TEXT, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(3.dp))
            Text(
                "${r.label} · 60일선 ${fmt(r.ma60SlopePct)}% · 정렬 ${(r.alignment * 100).toInt()}%",
                color = TEXT_DIM, fontSize = 11.sp
            )
        }
        Text("%.0f".format(r.score), color = accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun fmt(v: Double) = (if (v >= 0) "+" else "") + "%.1f".format(v)
