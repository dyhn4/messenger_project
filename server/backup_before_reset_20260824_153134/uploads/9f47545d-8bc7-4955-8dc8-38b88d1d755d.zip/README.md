# TrendScan — 키움 REST API 일봉 + 20/60일선 추세 스캐너

개인용 안드로이드 앱. 관심 종목의 일봉을 받아 20일·60일 이동평균선을 그리고,
우상향/우하향 추세를 점수로 정렬합니다.

## 파일 구성

| 파일 | 역할 |
|---|---|
| `KiwoomApi.kt` | 토큰 발급, ka10081 일봉 조회, 호출 제한 게이트, 연속조회 |
| `Indicators.kt` | SMA 계산, 추세 판정·점수화 |
| `CandleChart.kt` | Compose Canvas 캔들차트 + 이동평균선 |
| `ScreenerViewModel.kt` | 관심종목 순차 스캔, 캐시 |
| `MainScreen.kt` | 차트 + 순위 리스트 UI |
| `MainActivity.kt` | 진입점, 키 보관 |

패키지는 `com.example.trendscan` 기준입니다. 프로젝트에 맞게 바꾸세요.

## 선 색

첨부하신 설정 화면에서 추출한 값 그대로입니다.

| 기간 | 색 |
|---|---|
| 20일 | `#E6485C` |
| 60일 | `#EE8210` |

`CandleChart.kt` 상단의 `MA20_COLOR` / `MA60_COLOR` 상수 하나만 고치면 전체에 반영됩니다.

양봉 색을 `#D24B4B`로 20일선보다 살짝 어둡게 잡았습니다. 그냥 두면 빨간 캔들 위에서
20일선이 묻혀버립니다. 60일선을 먼저 그리고 20일선을 나중에 그려 겹칠 때 20일선이
위로 올라오게 했습니다.

## 의존성

```kotlin
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation(platform("androidx.compose:compose-bom:2024.09.02"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
```

`AndroidManifest.xml`에 인터넷 권한:
```xml
<uses-permission android:name="android.permission.INTERNET" />
```

## 시작하기

1. 키움 OpenAPI 포털(openapi.kiwoom.com)에서 REST API 사용 신청 → appkey / secret 발급
2. `MainActivity.kt`의 `prefs.edit()` 줄 주석을 풀고 키를 넣어 1회 실행
3. 실행 후 그 줄을 **다시 주석 처리하고 재빌드** (소스에 키가 남지 않게)
4. 첫 테스트는 `KiwoomApi(..., mock = true)`로 모의투자 서버에서

## 추세 판정 방식

"우상향으로 보인다"를 세 가지로 쪼개서 점수화합니다.

| 요소 | 계산 | 가중치 |
|---|---|---|
| 방향·세기 | 60일선의 최근 20거래일 변화율 (30%에서 포화) | 40% |
| 깔끔함 | log(종가) 선형회귀 R² (최근 120일) | 35% |
| 정배열 지속성 | 최근 60일 중 20일선이 60일선 위에 있던 비율 | 25% |

**R²가 이 로직의 핵심입니다.** 이게 없으면 "한 번 급등하고 옆으로 긴" 종목이
우상향 1위로 올라옵니다. 60일선 기울기만 보면 계단식 급등과 꾸준한 상승을 구분하지 못해요.
삼성전기·SK하이닉스처럼 눈으로 봐서 "예쁘게 우상향"인 종목을 잡으려는 게 목적이라면
R² 가중치를 더 올려도 됩니다.

방향 판정 임계값은 `analyzeTrend`의 `slopeThresholdPct = 3.0`입니다.
너무 많이 잡히면 5~7로 올리세요.

## 실제로 걸릴 만한 것들

**호출 제한.** TR별로 제한이 걸려 있어 `minIntervalMs = 1100`으로 전역 게이트를 뒀습니다.
종목 10개 스캔에 대략 15~25초 걸립니다(240봉 채우느라 종목당 2~3회 연속조회).
전 종목 스캔은 이 구조로는 무리입니다. 관심종목 30~50개가 현실적인 상한이에요.
그 이상 필요하면 밤에 WorkManager로 돌려 Room에 쌓아두는 구조로 바꾸세요.

**응답 필드명.** ka10081의 요청 파라미터(`stk_cd`, `base_dt`, `upd_stkpc_tp`)는 확인했지만,
응답 배열의 키 이름은 문서 개정으로 바뀔 수 있어 하드코딩하지 않았습니다.
`parseCandles()`가 **본문에서 가장 긴 JSON 배열**을 캔들 목록으로 잡고, 필드는 후보명을
순서대로 확인합니다. 처음 붙일 때 응답 원문을 한 번 로그로 찍어보고, 파싱이 비면
`num()`의 후보 키에 실제 이름을 추가하세요.

**토큰 응답 필드.** `token` / `access_token` 둘 다 확인하도록 해뒀습니다.

**수정주가.** `upd_stkpc_tp = "1"`(적용)이 기본값입니다. 이걸 끄면 액면분할 종목에
가짜 급락 갭이 생겨 이동평균선과 추세 판정이 전부 망가집니다.

**60일선이 그려지려면** 최소 60봉이 필요하고, 추세 판정에는 80봉을 요구합니다.
`minCount = 240`으로 넉넉히 받는 이유입니다. 신규 상장주는 결과에서 자동으로 빠집니다.

## 다음에 붙이면 좋을 것

- Room 캐시 — 매번 API를 때리지 않도록. 일봉은 하루 한 번만 갱신하면 충분합니다
- 크로스헤어 — 롱프레스 시 해당 일자의 OHLC와 두 이동평균값 표시
- 기간 프리셋 — 20/60에 더해 5일선, 120일선 토글
- 골든크로스 알림 — 20일선이 60일선을 상향 돌파한 날을 리스트에 배지로
