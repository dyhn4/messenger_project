package com.example.trendscan.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.trendscan.data.Candle
import com.example.trendscan.data.KiwoomApi
import com.example.trendscan.domain.Direction
import com.example.trendscan.domain.TrendResult
import com.example.trendscan.domain.analyzeTrend
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** 관심 종목. 이름은 표시용이라 직접 적어두는 게 호출 한 번 아끼는 길입니다. */
data class Watch(val code: String, val name: String)

val DEFAULT_WATCHLIST = listOf(
    Watch("005930", "삼성전자"),
    Watch("000660", "SK하이닉스"),
    Watch("009150", "삼성전기"),
    Watch("373220", "LG에너지솔루션"),
    Watch("207940", "삼성바이오로직스"),
    Watch("005380", "현대차"),
    Watch("035420", "NAVER"),
    Watch("068270", "셀트리온"),
    Watch("012450", "한화에어로스페이스"),
    Watch("042660", "한화오션"),
)

data class UiState(
    val scanning: Boolean = false,
    val progress: String = "",
    val results: List<TrendResult> = emptyList(),
    val filter: Direction? = null,
    val selected: String? = null,
    val candles: List<Candle> = emptyList(),
    val error: String? = null,
) {
    val visibleResults: List<TrendResult>
        get() = results
            .filter { filter == null || it.direction == filter }
            .sortedByDescending { it.score }
}

class ScreenerViewModel(private val api: KiwoomApi) : ViewModel() {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    // 스캔한 종목의 일봉을 들고 있다가 차트 전환 시 재호출을 피합니다.
    private val cache = mutableMapOf<String, List<Candle>>()

    fun scan(watchlist: List<Watch> = DEFAULT_WATCHLIST) {
        if (_state.value.scanning) return
        viewModelScope.launch {
            _state.update { it.copy(scanning = true, results = emptyList(), error = null) }
            val acc = mutableListOf<TrendResult>()

            watchlist.forEachIndexed { idx, w ->
                _state.update {
                    it.copy(progress = "${idx + 1}/${watchlist.size} ${w.name}")
                }
                try {
                    val candles = cache.getOrPut(w.code) {
                        api.dailyCandles(w.code, minCount = 240)
                    }
                    analyzeTrend(w.code, w.name, candles)?.let { r ->
                        acc += r
                        _state.update { s -> s.copy(results = acc.toList()) }
                    }
                } catch (e: Exception) {
                    // 한 종목이 실패해도 스캔 전체를 멈추지 않습니다.
                    _state.update { it.copy(error = "${w.name}: ${e.message}") }
                }
            }

            _state.update { it.copy(scanning = false, progress = "") }
            acc.maxByOrNull { it.score }?.let { select(it.code) }
        }
    }

    fun select(code: String) {
        viewModelScope.launch {
            _state.update { it.copy(selected = code) }
            val candles = cache[code] ?: runCatching { api.dailyCandles(code, 240) }
                .onFailure { e -> _state.update { it.copy(error = e.message) } }
                .getOrNull()
                ?.also { cache[code] = it }
                ?: return@launch
            _state.update { it.copy(candles = candles) }
        }
    }

    fun setFilter(d: Direction?) = _state.update { it.copy(filter = d) }
}
